#!/usr/bin/env bash
# Run the ANM comparisons in a new scratch workspace.
set -euo pipefail
MODE=${1:-extended}
SCRATCH=${2:?Usage: bash reproduce.sh extended\|original /path/to/scratch}
JOBS=${JOBS:-10}
[[ "$MODE" == extended || "$MODE" == original ]] || { echo 'Invalid protocol' >&2; exit 2; }
[[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || { echo 'JOBS must be positive' >&2; exit 2; }
HERE=$(cd -- "$(dirname -- "$0")" && pwd)
for cmd in git cmake python3 gcc nvcc nvidia-smi; do command -v "$cmd" >/dev/null; done
python3 -c 'import numpy; print("NumPy", numpy.__version__)'
[[ -d "$SCRATCH" && -w "$SCRATCH" ]] || { echo 'Scratch must exist and be writable' >&2; exit 2; }
SCRATCH=$(cd -- "$SCRATCH" && pwd)
W=$(mktemp -d "$SCRATCH/anm_h100_${MODE}.XXXXXX")
cd "$W"
printf 'Workspace: %s\n' "$W"
mkdir logs results
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
unset OXDNA_JOHN_DIAG OXDNA_DIAG_FORCE_DUMP OXDNA_DIAG_QUAT_TRACE
SUITE=a1da3dfc74d78cc2feb9f48a0a284f6744960d7e
UPSTREAM=81dafaa3a4c93da656904f4334db5e3bc54e9351
CORE=aa26e3236f6339e6a6429e327df35703ba2a391c
checkout(){
    local url=$1 dir=$2 sha=$3
    git clone "$url" "$dir"
    git -C "$dir" fetch origin "$sha"
    git -C "$dir" checkout --detach "$sha"
    [[ $(git -C "$dir" rev-parse HEAD) == "$sha" ]]
}
checkout https://github.com/ErikPoppleton/oxDNA_regression_tests.git suite "$SUITE"
if [[ "$MODE" == extended ]]; then
    git -C suite apply --check "$HERE/CLN025_stat_sampling.patch"
    git -C suite apply "$HERE/CLN025_stat_sampling.patch"
    git -C suite diff --check
    git -C suite diff > logs/applied_sampling.patch
fi
checkout https://github.com/GioacchinoSchifino/oxDNA.git upstream "$UPSTREAM"
checkout https://github.com/GioacchinoSchifino/oxDNA.git core "$CORE"
failed=0
build(){
    local src=$1 prec=$2
    local flags=(-DCUDA=OFF)
    case "$prec" in
        mixed) flags=(-DCUDA=ON -DCUDA_COMMON_ARCH=OFF);;
        double) flags=(-DCUDA=ON -DCUDA_DOUBLE=ON -DCUDA_COMMON_ARCH=OFF);;
    esac
    cmake -S "$src" -B "build/$src/$prec" "${flags[@]}" > "logs/${src}_${prec}_cmake.log" 2>&1
    cmake --build "build/$src/$prec" --target oxDNA --parallel "$JOBS" > "logs/${src}_${prec}_build.log" 2>&1
    test -x "build/$src/$prec/bin/oxDNA"
    sha256sum "build/$src/$prec/bin/oxDNA" > "logs/${src}_${prec}_binary.sha256"
}
run(){
    local src=$1 prec=$2 label=$3 rc=0; shift 3
    local name="${src}_${prec}_${label}"
    python3 -u suite/run_tests.py --same-code \
        --old "$W/build/$src/cpu/bin/oxDNA" --new "$W/build/$src/$prec/bin/oxDNA" \
        --backend CUDA --cuda-precision "$prec" --jobs "$JOBS" --gpu-jobs 1 \
        --out "$W/results/$name" "$@" > "logs/$name.log" 2>&1 || rc=$?
    printf '%s runner_exit=%s\n' "$name" "$rc" | tee -a logs/runner_status.txt
    if ((rc != 0)); then failed=1; fi
    if [[ ! -s "results/$name/results.json" || ! -s "results/$name/summary.md" ]]; then
        echo "Missing result files: $name" >&2; failed=1
    fi
}
for src in upstream core; do
    for prec in cpu mixed double; do build "$src" "$prec"; done
    for prec in mixed double; do
        if [[ "$src" == upstream ]]; then
            run "$src" "$prec" target --only cln025/DNACT cln025/RNACT --stages stat
        else
            run "$src" "$prec" full
        fi
    done
done
printf 'Reports retained in %s\n' "$W"
exit "$failed"
