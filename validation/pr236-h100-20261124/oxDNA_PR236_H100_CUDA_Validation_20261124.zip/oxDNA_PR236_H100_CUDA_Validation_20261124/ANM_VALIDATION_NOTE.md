# ANM refactor: H100 regression tests and the CLN025 sampling issue

Gioacchino Schifino — 24 November 2026

I followed up on the CUDA tests for the consolidated ANM fixes in [PR #2](https://github.com/GioacchinoSchifino/oxDNA/pull/2), using the regression suite Erik shared in [PR #236](https://github.com/lorenzo-rovigatti/oxDNA/pull/236). The full runs on an H100 initially failed two RMSF checks. I wanted to establish whether the discrepancy came from my changes, the CUDA implementation or the sampling before suggesting a fix.

## Regression results

I used the following revisions throughout this comparison:

| Repository / revision | Commit |
|---|---|
| Original ANM refactor | `81dafaa3a4c93da656904f4334db5e3bc54e9351` |
| My consolidated ANM fixes | `aa26e3236f6339e6a6429e327df35703ba2a391c` |
| `ErikPoppleton/oxDNA_regression_tests` | `a1da3dfc74d78cc2feb9f48a0a284f6744960d7e` |

The GPU was an NVIDIA H100 80 GB (HBM3), with GCC 13.1.0, CUDA 12.6.77, CMake 3.22.1, Python 3.12.12 and NumPy 2.4.2. I used `--same-code` to compare the CPU and CUDA builds of each revision. The build used the native CUDA architecture (9.0), with `CUDA_DOUBLE=ON` for double precision. The recorded CMake options and binary checksums are in `build/`.

| Code and protocol | Mixed: PASS / FAIL / SKIP | Double: PASS / FAIL / SKIP |
|---|---:|---:|
| Consolidated fixes, original full suite | 79 / 2 / 25 | 79 / 2 / 25 |
| Consolidated fixes, full suite with CLN025 extension | 81 / 0 / 25 | 81 / 0 / 25 |
| Original refactor, extended CLN025 stat tests only | 2 / 0 / 0 | 2 / 0 / 0 |

For each precision, the original and updated full suites cover the same 106 case/check combinations (27 cases). The only status changes are the two CLN025 `stat` failures. The 25 deterministic cross-backend comparisons remain skipped, as intended by the runner. The original mixed results are retained as a text summary; the other full runs have detailed JSON records. I did not run the full suite on the original refactor in this campaign.

## What I found for CLN025

The failures concern the protein-only CLN025 fixture (10 residues), under DNACT and RNACT. The models are equivalent for this fixture, so I do not count them as independent physical systems. The initial-energy and NVE checks passed. The short-protocol RMSF discrepancy was reproduced with two seed cohorts and both CUDA precisions. It was also present in a diagnostic run of the original refactor, before my ANM fixes.

I first compared the actual CPU and GPU forces and body-frame torques at initialization, bypassing host-side force observables. I used the three supplied configurations and 12 additional configurations with positional and orientational perturbations, for each code revision. On these 15 configurations, the maximum componentwise scaled errors were:

| Precision | Force | Torque |
|---|---:|---:|
| Mixed | 3.89e-4 | 6.96e-5 |
| Double | 1.70e-14 | 2.02e-14 |

The scale is `abs(a-b)/(1+abs(a)+abs(b))`, not a conventional relative error. The two revisions gave the same maxima. This is a check of the sampled configurations, not a test of every CUDA interaction path.

I also checked kinetic temperatures and quaternion norms, and compared John with Refresh as a diagnostic. Refresh passed in both precisions, but I would not replace John just to make the regression pass. In a separate John test I ran 120 simulations: 16 CPU, 12 mixed and 12 double replicas for each diffusion coefficient (1, 0.1 and 0.01). All nine CPU–CPU and CPU–CUDA comparisons passed using the original statistical criteria. For D=1, the measured translational and rotational refresh probabilities were close to the values expected from the implementation, and the means and variances of the refreshed moment components were close to their targets. The diagnostic counters and replica statistics are included in `diagnostics/`.

## Sampling length

The clearest comparison is the uninstrumented retest, keeping the original eight replicas per backend, seeds, temperature, timestep, John parameters and acceptance thresholds, and changing only the duration of the two CLN025 statistical tests from 300,000 to 1,200,000 steps.

| Precision / steps | Mean RMSF CPU (Å) | Mean RMSF GPU (Å) | Mean z² | Result |
|---|---:|---:|---:|---|
| Mixed / 300,000 | 0.410712 | 0.392508 | 5.7263 | FAIL |
| Mixed / 1,200,000 | 0.400171 | 0.404276 | 2.0203 | PASS |
| Double / 300,000 | 0.410712 | 0.390080 | 9.7813 | FAIL |
| Double / 1,200,000 | 0.400171 | 0.402042 | 0.5139 | PASS |

Here mean z² is the RMSF screening statistic used by the runner, with the original limit of 4. The residue RMSFs are correlated, so I do not interpret it as a chi-square test with ten independent observations. The extended results match exactly, at the saved JSON level, between the targeted runs on the original refactor, the targeted runs on my consolidated branch and the updated full suites on my branch.

Taken together, these tests point to insufficient sampling in the original CLN025 protocol. They do not exclude all possible backend differences, or establish formal equivalence of the underlying ensembles. In particular, the two precision comparisons share CPU reference cohorts in the original-seed tests, and the 120-run diagnostic varies more than just duration. The fixed-seed, uninstrumented comparison is the relevant control for the proposed change.

## Proposed change

I would increase `stat.steps` to 1,200,000 specifically for DNACT and RNACT in `systems/cln025/config.json`. The attached patch is the one used for the final full runs. AC and the quick settings are unchanged; the override also applies to these two cases when they are selected for full CPU/original-mode runs. I have not changed the force field, the thermostat, the tolerances, or the CI configuration.

The JSON results, exact patch, diagnostic methods and build records are included for review. `REPRODUCE.md` gives the commands for the uninstrumented runs and explains the separate diagnostics. The bundle contains saved summaries and replica aggregates, not raw trajectories or force-array dumps; I can provide the compact run archives separately if needed. This note concerns the ANM changes only, not the separate protein electrostatics implementation.
