#!/usr/bin/env python3
"""Narrow CLN025 protocol update; refuse drift from pinned config assumptions."""
import copy, json, sys
from pathlib import Path

def patch(original):
    old=json.loads(original)
    assert old['stages']['stat']['steps']==300000
    assert old['stages']['stat']['replicas']==8
    assert old['stages']['stat']['quick']['steps']==60000
    expected=copy.deepcopy(old)
    output=original
    for name in ('DNACT','RNACT'):
        assert 'stages' not in old['cases'][name], f'{name}: unexpected existing overrides'
        expected['cases'][name]['stages']={'stat': {'steps':1200000}}
        anchor=f'    "{name}": {{\n'
        assert output.count(anchor)==1, f'{name}: nonunique anchor'
        output=output.replace(anchor,anchor+'      "stages": {\n        "stat": {\n          "steps": 1200000\n        }\n      },\n',1)
    assert json.loads(output)==expected, 'Unexpected semantic change'
    return output
if __name__=='__main__':
    p=Path(sys.argv[1]); original=p.read_text(); p.write_text(patch(original))
    print('CLN025_PATCH_OK: only case-specific stat steps; shared settings, quick and smoke preserved')
