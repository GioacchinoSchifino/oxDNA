from pathlib import Path
from types import SimpleNamespace
import concurrent.futures as cf
import json, math, os, shutil, subprocess, sys, threading, tarfile
import numpy as np
work, report, suite=map(lambda a:Path(a).resolve(),sys.argv[1:4])
sys.path.insert(0,str(suite))
import run_tests as rt
from regtest import oxio, analysis
case=next(c for c in rt.load_cases(SimpleNamespace(only=['cln025/DNACT'],quick=False,smoke=False,mode='same_code',backend='CUDA')) if c['name']=='cln025/DNACT')
# New, disjoint seed sets between cohorts and conditions. CPU 16, GPU 12 each.
conditions=[('D1_long',1.0,1200000),('D0p1',0.1,600000),('D0p01',0.01,300000)]
backends={'cpu':('CPU',16,41000),'cuda_mixed':('CUDA',12,51000),'cuda_double':('CUDA_double',12,61000)}
T=0.1; dt=.002; interval=51
rng=np.random.default_rng(772366)
sem=threading.Semaphore(1)
workers=int(os.getenv('SLURM_CPUS_PER_TASK','10'))

def read_counter(p,steps):
    a=np.loadtxt(p,ndmin=1)
    if a.shape!=(16,) or not np.isfinite(a).all(): raise ValueError(f'invalid counters {p}: {a.shape}')
    acts,trials,nt,nr=map(int,a[:4]); n=np.array([nt,nr],dtype=int)
    if trials!=10*acts or not np.all((0<n)&(n<=trials)) or abs(acts-steps//interval)>101:
        raise ValueError(f'counter coverage invalid: {a[:4]} expected {steps//interval} activations')
    m=a[4:].reshape(2,3,2)
    return {'activations':acts,'trials':trials,'counts':n.tolist(),'sum':m[:,:,0].tolist(),'sumsq':m[:,:,1].tolist()}

def analyze_rep(d,steps):
    # Original RMSF method, and explicit kinetic temperatures from all 15 columns.
    t,b,x=oxio.read_trajectory(d/'trajectory.dat',cols=15)
    if x.ndim!=3 or x.shape[1:]!=(10,15) or len(x)<steps//500 or not np.isfinite(x).all(): raise ValueError(f'invalid trajectory {d}: {x.shape}')
    en=oxio.read_energy(d/'energy.dat')
    if len(en)<steps//500 or not np.isfinite(en[:,:4]).all(): raise ValueError(f'incomplete energy file {d}')
    eq=int(.2*len(x)); xx=x[eq:]
    rmsf,_=analysis.trajectory_rmsf(x,b,np.arange(10),.2,5)
    # For comparison to the short protocol, first 300k steps only (incl initial frame when present).
    nshort=min(len(x),601); short,_=analysis.trajectory_rmsf(x[:nshort],b[:nshort],np.arange(10),.2,5)
    half=len(x)//2
    late,_=analysis.trajectory_rmsf(x[half:],b[half:],np.arange(10),0.,5)
    return {'nframes':len(x),'rmsf':rmsf.tolist(),'rmsf_first300k':short.tolist(),'rmsf_last_half':late.tolist(),
            'energy_mean':float(np.mean(en[int(.2*len(en)):,1])), 'Ttrans':float(np.mean(np.sum(xx[:,:,9:12]**2,axis=2))/3),
            'Trot':float(np.mean(np.sum(xx[:,:,12:15]**2,axis=2))/3),'counter':read_counter(d/'john_counts.dat',steps)}

def run_rep(backend,d,steps,diff,seed):
    btag=backends[backend][0]; binary=work/'build'/backend/'bin/oxDNA'; d.mkdir(parents=True)
    rt.make_input(case,['new'],btag,{'steps':steps,'dt':dt,'thermostat':'john','newtonian_steps':interval,'diff_coeff':diff,'seed':seed,'conf_file':str(Path(case['dir'])/'equilibrated.dat'),'print_energy_every':500,'print_conf_interval':500},str(d))
    env=os.environ.copy(); env['OXDNA_JOHN_DIAG']='john_counts.dat'
    def run():
        with (d/'stdout.txt').open('w') as f:
            return subprocess.run([str(binary),'input'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400).returncode
    if backend=='cpu': rc=run()
    else:
        with sem: rc=run()
    if rc: raise RuntimeError(f'{d}: oxDNA exited {rc}')
    m=analyze_rep(d,steps);m.update({'backend':backend,'seed':seed,'replica':d.name})
    print('REPLICA_OK',d.parent.parent.name,backend,d.name,'Trot',m['Trot'],flush=True)
    return m

def pooled(rs,diff):
    tr=sum(r['counter']['trials'] for r in rs); n=np.sum([r['counter']['counts'] for r in rs],axis=0); su=np.sum([r['counter']['sum'] for r in rs],axis=0); sq=np.sum([r['counter']['sumsq'] for r in rs],axis=0)
    # BrownianThermostat::init derives pr with Dr=3Dt.
    p=np.array([2*T*interval*dt/(T*interval*dt+2*diff),2*T*interval*dt/(T*interval*dt+6*diff)])
    freq=n/tr; mz=(n-tr*p)/np.sqrt(tr*p*(1-p)); mu=su/n[:,None]; var=sq/n[:,None]-mu**2
    def ms(k):
        v=np.array([r[k] for r in rs]);return [float(v.mean()),float(v.std(ddof=1)/np.sqrt(len(v)))]
    return {'replicas':len(rs),'trials':tr,'draws':n.tolist(),'expected_probability':p.tolist(),'observed_probability':freq.tolist(),'count_z_binomial':mz.tolist(),'draw_mean_xyz':mu.tolist(),'draw_variance_xyz':var.tolist(),'Ttrans_mean_se':ms('Ttrans'),'Trot_mean_se':ms('Trot'),'E_mean_se':ms('energy_mean')}

def comparison(a,b,key):
    # One scalar per independent replica. No independence assumption across residues.
    x=np.array([np.mean(r[key]) for r in a]); y=np.array([np.mean(r[key]) for r in b]); delta=y.mean()-x.mean(); pool=np.r_[x,y]; n=len(x)
    # Nonparametric replica bootstrap and two-sided random-label permutation test, descriptive.
    nb=20000
    boot=y[rng.integers(len(y),size=(nb,len(y)))].mean(1)-x[rng.integers(len(x),size=(nb,len(x)))].mean(1)
    exc=0
    for _ in range(nb):
        z=rng.permutation(pool); exc+=abs(z[n:].mean()-z[:n].mean())>=abs(delta)
    return {'old_n':len(x),'new_n':len(y),'old_mean':float(x.mean()),'new_mean':float(y.mean()),'delta':float(delta),'bootstrap95':np.quantile(boot,[.025,.975]).tolist(),'permutation_p_unadjusted':(exc+1)/(nb+1)}

def original_check(cdir,old_paths,new_paths,btag):
    # Run the original Erik statistical comparison without changing thresholds.
    stage=cdir/'compare';stage.mkdir()
    for side,paths in [('old',old_paths),('new',new_paths)]:
        dd=stage/side; dd.mkdir()
        for i,p in enumerate(paths): (dd/f'rep{i:02d}').symlink_to(p,target_is_directory=True)
    args=SimpleNamespace(quick=False,smoke=False,mode='same_code',btag=btag,old_btag='CPU',old='cpu',new='test')
    st,msg,data=rt.compare_stat(case,str(stage),args)
    return {'status':st,'message':msg,'data':data}

results=[]
for ci,(label,diff,steps) in enumerate(conditions):
    cd=work/'runs'/label;cd.mkdir(parents=True)
    print('CONDITION_START',label,steps,diff,flush=True)
    jobs=[]
    for bk,(tag,n,base) in backends.items():
        for i in range(n):jobs.append((bk,cd/bk/f'rep{i:02d}',steps,diff,base+ci*100+i))
    # CPU tasks submitted first; GPU simulations serialized by semaphore.
    rows=[]; errors=[]
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        fut={ex.submit(run_rep,*j):j for j in jobs}
        for f in cf.as_completed(fut):
            try: rows.append(f.result())
            except Exception as e: errors.append({'job':str(fut[f][1]),'error':str(e)});print('REPLICA_ERROR',errors[-1],flush=True)
            (report/f'{label}_replicas.json').write_text(json.dumps({'rows':rows,'errors':errors},indent=2))
    if errors or len(rows)!=len(jobs): raise RuntimeError(f'{label} incomplete, see {label}_replicas.json; scratch retained')
    by={bk:sorted([r for r in rows if r['backend']==bk],key=lambda r:r['seed']) for bk in backends}
    summary={'condition':label,'diff_coeff':diff,'steps':steps,'backends':{bk:pooled(rs,diff) for bk,rs in by.items()},'comparisons':{}}
    for name,a,b,old_bk,new_bk in [('cpu_cpu',by['cpu'][:8],by['cpu'][8:],'cpu','cpu'),('cpu_mixed',by['cpu'],by['cuda_mixed'],'cpu','cuda_mixed'),('cpu_double',by['cpu'],by['cuda_double'],'cpu','cuda_double')]:
        cc=cd/name;cc.mkdir(); old_paths=[cd/old_bk/r['replica'] for r in a];new_paths=[cd/new_bk/r['replica'] for r in b]
        summary['comparisons'][name]={'original_stat':original_check(cc,old_paths,new_paths,backends[new_bk][0]),'full':comparison(a,b,'rmsf'),'first300k':comparison(a,b,'rmsf_first300k'),'last_half':comparison(a,b,'rmsf_last_half')}
    results.append(summary)
    (report/'john_summary.json').write_text(json.dumps(results,indent=2,default=float))
    # Preserve all compact evidence; raw trajectories optionally archived with explicit cap.
    files=[p for bk in backends for p in (cd/bk).rglob('*') if p.is_file() and p.name in ('input','energy.dat','log.dat','stdout.txt','john_counts.dat','last_conf.dat','trajectory.dat')]
    size=sum(p.stat().st_size for p in files);cap=256*1024*1024
    if size>cap: files=[p for p in files if p.name!='trajectory.dat'];print('TRAJECTORIES_NOT_ARCHIVED',label,size,flush=True)
    if sum(p.stat().st_size for p in files)>cap:raise RuntimeError('compact evidence exceeds archive cap')
    with tarfile.open(report/f'{label}_evidence.tar.gz','w:gz',compresslevel=3) as tar:
        for p in files:tar.add(p,arcname=str(p.relative_to(cd)),recursive=False)
    print('CONDITION_DONE',label,flush=True)
    # Delete only this completed condition scratch; report and original sources untouched.
    shutil.rmtree(cd)
    with (report/'john_summary.txt').open('w') as f:
        print('John thermostat diagnostic; original stat thresholds unchanged. Bootstrap and permutation are replica-level descriptive diagnostics (not adjusted for multiple tests).',file=f)
        for s in results:
            print('\n',s['condition'],'D',s['diff_coeff'],'steps',s['steps'],file=f)
            for bk,p in s['backends'].items():
                print(bk,'Ttrans mean,SE',p['Ttrans_mean_se'],'Trot mean,SE',p['Trot_mean_se'],'p_expected',p['expected_probability'],'p_observed',p['observed_probability'],'count_z',p['count_z_binomial'],'draw_mean_xyz',p['draw_mean_xyz'],'draw_var_xyz',p['draw_variance_xyz'],file=f)
            for name,c in s['comparisons'].items():
                print(name,c['original_stat']['status'],c['original_stat']['message'],file=f)
                for k in ['first300k','full','last_half']: print(' ',k,c[k],file=f)
print('JOHN_DIAGNOSTIC_COMPLETE; statistical FAILs are recorded as results',flush=True)
