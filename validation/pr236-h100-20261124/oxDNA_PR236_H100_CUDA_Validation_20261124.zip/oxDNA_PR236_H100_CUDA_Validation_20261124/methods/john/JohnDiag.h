#pragma once
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
// Diagnostic counters only. No changes to random numbers or dynamics.
struct JohnDiag {
    unsigned long long activations=0, attempts=0, count[2]={0,0};
    double sum[2][3]={{0,0,0},{0,0,0}}, sq[2][3]={{0,0,0},{0,0,0}};
    void draw(int k,double x,double y,double z) {
        double a[3]={x,y,z}; ++count[k];
        for(int i=0;i<3;i++){sum[k][i]+=a[i];sq[k][i]+=a[i]*a[i];}
    }
    void tick(const char* path,unsigned n) {
        ++activations; attempts+=n;
        if(activations!=1 && activations%100!=0) return;
        std::FILE* f=std::fopen(path,"w");
        if(!f) throw std::runtime_error("cannot write John diagnostic counters");
        std::fprintf(f,"%llu %llu %llu %llu",activations,attempts,count[0],count[1]);
        for(int k=0;k<2;k++) for(int i=0;i<3;i++) std::fprintf(f," %.17g %.17g",sum[k][i],sq[k][i]);
        std::fprintf(f,"\n"); std::fclose(f);
    }
};
