from pathlib import Path
import sys
root=Path(sys.argv[1])
def rep(s,a,b):
    if s.count(a)!=1: raise RuntimeError(f'anchor count {s.count(a)}: {a[:100]}')
    return s.replace(a,b,1)
header=root/'src/Utilities/JohnDiag.h'
assert not header.exists()
header.write_text(r'''#pragma once
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
// Diagnostic counters only. No changes to random numbers or dynamics.
struct JohnDiag {
    unsigned long long activations=0, attempts=0, count[2]={0,0};
    double sum[2][3]={{0,0,0},{0,0,0}}, sq[2][3]={{0,0,0},{0,0,0}};
    void draw(int k,double x,double y,double z) {
        double a[3]={x,y,z}; ++count[k];
        for(int i=0;i<3;i++){sum[k][i]+=a[i];sq[k][i]+=a[i]*a[i];}
    }
    void tick(const char* path,unsigned n) {
        ++activations; attempts+=n;
        if(activations!=1 && activations%100!=0) return;
        std::FILE* f=std::fopen(path,"w");
        if(!f) throw std::runtime_error("cannot write John diagnostic counters");
        std::fprintf(f,"%llu %llu %llu %llu",activations,attempts,count[0],count[1]);
        for(int k=0;k<2;k++) for(int i=0;i<3;i++) std::fprintf(f," %.17g %.17g",sum[k][i],sq[k][i]);
        std::fprintf(f,"\n"); std::fclose(f);
    }
};
''')
p=root/'src/Backends/Thermostats/BrownianThermostat.cpp'; s=p.read_text()
s=rep(s,'#include "BrownianThermostat.h"','#include "BrownianThermostat.h"\n#include "../../Utilities/JohnDiag.h"')
s=rep(s,'\tif(curr_step % _newtonian_steps) return;','\tif(curr_step % _newtonian_steps) return;\n\tconst char* diag=std::getenv("OXDNA_JOHN_DIAG");\n\tstatic JohnDiag counts;')
a='\t\t\tp->vel = LR_vector(Utils::gaussian(), Utils::gaussian(), Utils::gaussian()) * _rescale_factor;'
s=rep(s,a,a+'\n\t\t\tif(diag) counts.draw(0,p->vel.x,p->vel.y,p->vel.z);')
a='\t\t\tp->L = LR_vector(Utils::gaussian(), Utils::gaussian(), Utils::gaussian()) * _rescale_factor;'
s=rep(s,a,a+'\n\t\t\tif(diag) counts.draw(1,p->L.x,p->L.y,p->L.z);')
a='\t\t\tif(diag) counts.draw(1,p->L.x,p->L.y,p->L.z);\n\t\t}\n\t}\n}'
s=rep(s,a,a[:-1]+'\tif(diag) counts.tick(diag,particles.size());\n}')
p.write_text(s)
p=root/'src/CUDA/Backends/MD_CUDABackend.cu'; s=p.read_text()
s=rep(s,'#include <typeinfo>','#include <typeinfo>\n#include <vector>\n#include "../../Utilities/JohnDiag.h"')
a='void MD_CUDABackend::_thermalize() {\n\t_cuda_thermostat->apply_cuda(_d_poss, _d_orientations, _d_vels, _d_Ls, current_step());\n}'
b=r'''void MD_CUDABackend::_thermalize() {
    const char* diag=std::getenv("OXDNA_JOHN_DIAG");
    if(diag && _cuda_thermostat->would_activate(current_step())) {
        static JohnDiag counts;
        static std::vector<c_number4> v0(N()), l0(N()), v1(N()), l1(N());
        CUDA_SAFE_CALL(cudaMemcpy(v0.data(),_d_vels,_vec_size,cudaMemcpyDeviceToHost));
        CUDA_SAFE_CALL(cudaMemcpy(l0.data(),_d_Ls,_vec_size,cudaMemcpyDeviceToHost));
        _cuda_thermostat->apply_cuda(_d_poss, _d_orientations, _d_vels, _d_Ls, current_step());
        CUDA_SAFE_CALL(cudaMemcpy(v1.data(),_d_vels,_vec_size,cudaMemcpyDeviceToHost));
        CUDA_SAFE_CALL(cudaMemcpy(l1.data(),_d_Ls,_vec_size,cudaMemcpyDeviceToHost));
        for(int i=0;i<N();++i){
            if(v0[i].x!=v1[i].x || v0[i].y!=v1[i].y || v0[i].z!=v1[i].z) counts.draw(0,v1[i].x,v1[i].y,v1[i].z);
            if(l0[i].x!=l1[i].x || l0[i].y!=l1[i].y || l0[i].z!=l1[i].z) counts.draw(1,l1[i].x,l1[i].y,l1[i].z);
        }
        counts.tick(diag,N());
    }
    else _cuda_thermostat->apply_cuda(_d_poss, _d_orientations, _d_vels, _d_Ls, current_step());
}'''
s=rep(s,a,b);p.write_text(s)
print('JOHN_AUDIT_INSTRUMENTATION_OK')
