#!/usr/bin/env python3
"""Phase A: directly compare the initial GPU and CPU force/torque vectors.
Phase B: standard CLN025/ANMT comparisons, baseline vs patched, with raw quaternion
norm and kinetic diagnostics. No tolerances in Erik's suite are changed.
"""
import json, math, os, subprocess, sys, traceback
from pathlib import Path
import numpy as np

work, report, suite = map(lambda x: Path(x).resolve(), sys.argv[1:4])
sys.path.insert(0, str(suite))
import run_tests as rt
from regtest import oxio
from types import SimpleNamespace
case=next(c for c in rt.load_cases(SimpleNamespace(only=['cln025/DNACT'], quick=False,smoke=False,mode='same_code',backend='CUDA')) if c['name']=='cln025/DNACT')
sysdir=Path(case['dir'])
report.mkdir(exist_ok=True)

def run_sub(binary, d, force=False, trace=False):
    env=os.environ.copy()
    env.pop('OXDNA_DIAG_FORCE_DUMP',None); env.pop('OXDNA_DIAG_QUAT_TRACE',None)
    if force: env['OXDNA_DIAG_FORCE_DUMP']=str(d/'force_raw.dat')
    if trace: env['OXDNA_DIAG_QUAT_TRACE']='quat_trace.dat'
    with (d/'stdout.txt').open('w') as f:
        p=subprocess.run([str(binary),'input'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
    if p.returncode: raise RuntimeError(f'{d}: exit={p.returncode}; see stdout.txt/log.dat')

def get_bin(source, backend):
    return work/'build'/source/backend/'bin/oxDNA'

def rotation(rng, sigma):
    axis=rng.normal(size=3); axis/=np.linalg.norm(axis)
    a=rng.normal(scale=sigma); x,y,z=axis
    K=np.array([[0,-z,y],[z,0,-x],[-y,x,0.]])
    return np.eye(3)+np.sin(a)*K+(1-np.cos(a))*(K@K)

snapdir=work/'snapshots'; snapdir.mkdir(exist_ok=True)
snaps=[]
for name in ['conf','equilibrated','perturbed']:
    p=sysdir/f'{name}.dat'
    if not p.is_file(): raise FileNotFoundError(p)
    snaps.append((name,p))
box,conf=oxio.read_conf(sysdir/'equilibrated.dat')
assert conf.shape==(10,15),f'expected 10 rigid bodies and 15 columns: got {conf.shape}'
assert np.isfinite(conf).all()
rng=np.random.default_rng(236025)
for j in range(12):
    a=conf.copy()
    a[:,:3]+=rng.normal(scale=0.012 if j<6 else 0.025,size=(10,3))
    for k in range(10):
        R=rotation(rng,0.12 if j<6 else 0.25)
        a[k,3:6]=R@a[k,3:6]; a[k,6:9]=R@a[k,6:9]
    p=snapdir/f'rotpos_{j:02d}.dat'
    with p.open('w') as f:
        f.write('t = 0\nb = '+' '.join(f'{x:.17g}' for x in box)+'\nE = 0 0 0\n')
        np.savetxt(f,a,fmt='%.17g')
    snaps.append((p.stem,p))

def read_dump(p):
    a=np.loadtxt(p,ndmin=2)
    assert a.shape==(10,10) and np.isfinite(a).all(),(str(p),a.shape)
    a=a[np.argsort(a[:,0])]; assert np.array_equal(a[:,0],np.arange(10))
    return a

def errors(ref,test):
    d=test-ref
    rel=np.abs(d)/(1+np.abs(ref)+np.abs(test))
    i,j=np.unravel_index(np.argmax(rel),rel.shape)
    return {'max_abs':float(np.max(np.abs(d))), 'rms_abs':float(np.sqrt(np.mean(d*d))),
        'max_scaled':float(rel[i,j]), 'max_scaled_particle':int(i),'component':int(j),
        'ref':float(ref[i,j]),'test':float(test[i,j])}

records=[]; failures=[]
for source in ['patched','upstream']:
    for name,confpath in snaps:
        dumps={}
        for backend,btag in [('cpu','CPU'),('cuda_mixed','CUDA'),('cuda_double','CUDA_double')]:
            d=report/'force_cases'/source/name/backend
            d.mkdir(parents=True,exist_ok=True)
            try:
                rt.make_input(case,['new'],btag,{'steps':1,'conf_file':str(confpath),'dt':1e-6,'thermostat':'no','refresh_vel':1,'seed':1,'external_forces':0,'print_energy_every':1,'print_conf_interval':1},str(d))
                run_sub(get_bin(source,backend),d,force=True)
                dumps[backend]=read_dump(d/'force_raw.dat')
            except Exception as e:
                failures.append({'source':source,'snapshot':name,'backend':backend,'error':str(e)})
                print('FORCE_PROBE_ERROR',failures[-1],flush=True)
        if 'cpu' not in dumps: continue
        for backend in ('cuda_mixed','cuda_double'):
            if backend not in dumps: continue
            r,t=dumps['cpu'],dumps[backend]
            row={'source':source,'snapshot':name,'backend':backend,'position':errors(r[:,1:4],t[:,1:4]),'force':errors(r[:,4:7],t[:,4:7]),'torque':errors(r[:,7:10],t[:,7:10])}
            records.append(row)
            print('DIRECT',source,name,backend,'F scaled %.8g'%row['force']['max_scaled'],'T scaled %.8g'%row['torque']['max_scaled'],flush=True)
(report/'direct_force_comparison.json').write_text(json.dumps({'records':records,'errors':failures},indent=2))
with (report/'direct_force_summary.txt').open('w') as f:
    print('Actual GPU arrays versus actual CPU force/torque arrays at initialization. Body-frame torque; same input geometry. Scaled error = |a-b|/(1+|a|+|b|). Screening only, not a formal acceptance tolerance.',file=f)
    for source in ('patched','upstream'):
        for backend in ('cuda_mixed','cuda_double'):
            sel=[x for x in records if x['source']==source and x['backend']==backend]
            print(source,backend,'snapshots',len(sel),'/ 15',file=f)
            for key in ('position','force','torque'):
                if sel:
                    worst=max(sel,key=lambda r:r[key]['max_scaled'])
                    print(' ',key,'worst_scaled=',worst[key]['max_scaled'],'worst_snapshot=',worst['snapshot'],'max_abs_across=',max(r[key]['max_abs'] for r in sel),file=f)
    print('probe_errors=',len(failures),file=f)
if failures or len(records)!=60:
    print('INCOMPLETE_DIRECT_PROBES; inspect errors before further tests',flush=True)
    sys.exit(3)

# Independent mechanism checks: the exact unmodified suite, with the standard seeds
# on the upstream source, then a current-code comparison using the same seeds and
# an alternate refresh thermostat. The statistical criterion remains unchanged.
# The diagnostic wrapper is allowed to record individual FAILs without aborting.
# Copy only compact evidence; discard scratch trajectories AFTER extracting metrics.
import shutil, tarfile
alt=work/'refresh_suite'; shutil.copytree(suite,alt,ignore=shutil.ignore_patterns('.git','__pycache__','results'))
alt_runner=alt/'run_tests.py'; s=alt_runner.read_text()
old="'thermostat': 'john',"
assert s.count(old)==1,'unexpected thermostat anchor'
alt_runner.write_text(s.replace(old,"'thermostat': 'refresh',",1))
(report/'refresh_runner_change.txt').write_text("Only BASE_INPUT thermostat john -> refresh. Same newtonian_steps=51, steps, seeds and statistical thresholds. Different thermostat; diagnostic, not an upstream regression replacement.\n")

def kinetic_metrics(d):
    values=[]
    for p in sorted(d.glob('*/trajectory.dat')):
        try:
            times,boxes,dat=oxio.read_trajectory(p,cols=15)
            if dat.ndim!=3 or dat.shape[1:]!=(10,15) or len(dat)<100 or not np.isfinite(dat).all():
                raise ValueError(f'invalid trajectory shape/values {dat.shape}')
            x=dat[int(len(dat)*0.2):]
            ttr=float(np.mean(np.sum(x[:,:,9:12]**2,axis=2))/3)
            trot=float(np.mean(np.sum(x[:,:,12:15]**2,axis=2))/3)
            if not (math.isfinite(ttr) and math.isfinite(trot)): raise ValueError('nonfinite kinetic temperature')
            qpath=p.parent/'quat_trace.dat'; qdev=None
            if qpath.exists():
                q=np.loadtxt(qpath,ndmin=2)
                if q.shape[1]==3 and np.isfinite(q).all():
                    qdev=float(np.max(np.abs(q[:,2]-1)))
            values.append({'replica':p.parent.name,'T_trans':ttr,'T_rot':trot,'max_quat_norm2_error':qdev,'frames':len(dat)})
        except Exception as e: values.append({'replica':p.parent.name,'error':str(e)})
    return values

stats=[]
for label,source,runner in [('upstream_john','upstream',suite/'run_tests.py'),('patched_john','patched',suite/'run_tests.py'),('patched_refresh','patched',alt_runner)]:
    for backend,prec in [('cuda_mixed','mixed'),('cuda_double','double')]:
        name=f'{label}_{prec}'; out=work/'stats'/name
        env=os.environ.copy();env.pop('OXDNA_DIAG_FORCE_DUMP',None);env['OXDNA_DIAG_QUAT_TRACE']='quat_trace.dat'
        args=[sys.executable,str(runner),'--same-code','--old',str(get_bin(source,'cpu')),'--new',str(get_bin(source,backend)),'--backend','CUDA','--cuda-precision',prec,'--jobs',os.environ.get('SLURM_CPUS_PER_TASK','10'),'--gpu-jobs','1','--only','cln025/DNACT','--stages','stat','--out',str(out)]
        print('STAT_START',name,flush=True)
        with (report/f'{name}.log').open('w') as f:
            p=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=3600)
        if not (out/'results.json').is_file():
            stats.append({'label':name,'error':f'runner rc {p.returncode}, missing results'}); print('STAT_ERROR',name,flush=True); continue
        for fname in ['results.json','summary.md']:
            shutil.copy2(out/fname,report/f'{name}_{fname}')
        data=json.loads((out/'results.json').read_text()); assert len(data)==1
        chk=data[0]['checks']['stat']; kroot=out/'cln025/DNACT/stat'
        km={side:kinetic_metrics(kroot/side) for side in ['old','new']}
        record={'label':name,'runner_rc':p.returncode,'stat_status':chk['status'],'message':chk['message'],'kinetics':km}
        for side in ('old','new'):
            entries=[v for v in km[side] if 'T_trans' in v]
            if entries:
                for key in ('T_trans','T_rot'):
                    z=np.array([v[key] for v in entries]); record[f'{side}_{key}_mean']=float(z.mean()); record[f'{side}_{key}_se']=float(z.std(ddof=1)/np.sqrt(len(z))) if len(z)>1 else None
                qvals=[v['max_quat_norm2_error'] for v in entries if v['max_quat_norm2_error'] is not None]
                if qvals: record[f'{side}_max_quat_norm2_error']=max(qvals)
            record[f'{side}_n_kinetic_replicas']=len(entries)
        stats.append(record)
        # Keep the small-system raw evidence as well. Never silently lose
        # trajectories, and never archive unrelated files. Bound the archive.
        keep={'input','energy.dat','trajectory.dat','quat_trace.dat','log.dat','stdout.txt','last_conf.dat'}
        selected=[p for p in kroot.rglob('*') if p.is_file() and p.name in keep]
        size=sum(p.stat().st_size for p in selected)
        if size <= 128*1024*1024:
            with tarfile.open(report/f'{name}_replica_evidence.tar.gz','w:gz',compresslevel=3) as tar:
                for path in sorted(selected):
                    tar.add(path,arcname=str(path.relative_to(kroot)),recursive=False)
            record['replica_evidence_archive']=f'{name}_replica_evidence.tar.gz'
            record['replica_evidence_bytes_before_compression']=size
        else:
            record['replica_evidence_archive']='omitted: 128 MiB condition limit'
            record['replica_evidence_bytes_before_compression']=size
            print('EVIDENCE_ARCHIVE_SKIPPED', name, size,flush=True)
        # Save JSON after each condition, including all compact per-replica values.
        (report/'mechanism_stats.json').write_text(json.dumps(stats,indent=2))
        print('STAT_DONE',name,'rc',p.returncode,'status',chk['status'],flush=True)
with (report/'mechanism_summary.txt').open('w') as f:
    print('Original statistical threshold unchanged; refresh is a diagnostic alternate thermostat, not a replacement for john.',file=f)
    for row in stats:
        print(row['label'],row.get('stat_status','ERROR'),row.get('message',row.get('error')),file=f)
        for side in ('old','new'):
            print('  ',side,'kinetic replicas',row.get(side+'_n_kinetic_replicas'), 'Ttrans',row.get(side+'_T_trans_mean'),'SE',row.get(side+'_T_trans_se'),'Trot',row.get(side+'_T_rot_mean'),'SE',row.get(side+'_T_rot_se'),'max |q^2-1|',row.get(side+'_max_quat_norm2_error'),file=f)
    print('Ttrans/Trot in oxDNA units (target 0.1 for unit mass/inertia and three DOF); verify trajectory output actually includes velocities and angular momenta.',file=f)
print('DIAG_RESULTS_WRITTEN (individual FAIL is an outcome, not a job crash)',flush=True)
if len(stats)!=6 or any('error' in x or x.get('stat_status') not in ('PASS','FAIL') or x.get('old_n_kinetic_replicas')!=8 or x.get('new_n_kinetic_replicas')!=8 for x in stats):
    print('INCOMPLETE_STAT_OR_KINETIC_EVIDENCE',flush=True); sys.exit(4)
