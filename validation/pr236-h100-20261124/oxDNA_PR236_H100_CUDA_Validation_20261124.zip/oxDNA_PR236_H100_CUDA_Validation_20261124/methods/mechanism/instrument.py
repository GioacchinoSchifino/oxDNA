#!/usr/bin/env python3
"""Instrument a private scratch checkout, never the real repository."""
from pathlib import Path
import sys
root=Path(sys.argv[1])

def replace_once(s,old,new,label):
    if s.count(old)!=1:
        raise RuntimeError(f'{label}: expected unique anchor, found {s.count(old)}')
    return s.replace(old,new,1)

cpu=root/'src/Backends/MD_CPUBackend.cpp'
s=cpu.read_text()
s=replace_once(s,'#include <sstream>', '#include <sstream>\n#include <cstdio>\n#include <cstdlib>','CPU includes')
anchor='\t_compute_forces();\n}\n\nvoid MD_CPUBackend::_first_step()'
body=r'''\t_compute_forces();
	// Diagnostic only: export the actual initial force/torque arrays.
	if(const char *diag = std::getenv("OXDNA_DIAG_FORCE_DUMP")) {
		std::FILE *fp = std::fopen(diag, "w");
		if(!fp) throw oxDNAException("CLN025 diagnostic: cannot write force dump");
		for(auto p : _particles) {
			std::fprintf(fp, "%d %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g\n",
				p->index, double(p->pos.x), double(p->pos.y), double(p->pos.z),
				double(p->force.x), double(p->force.y), double(p->force.z),
				double(p->torque.x), double(p->torque.y), double(p->torque.z));
		}
		std::fclose(fp);
	}
}

void MD_CPUBackend::_first_step()'''.replace(r'\t_compute_forces();','\t_compute_forces();',1)
s=replace_once(s,anchor,body,'CPU initial force hook')
cpu.write_text(s)

gpu=root/'src/CUDA/Backends/MD_CUDABackend.cu'
s=gpu.read_text()
s=replace_once(s,'#include <typeinfo>','#include <typeinfo>\n#include <cstdio>\n#include <cstdlib>','CUDA includes')
# Insert only after the actual initial GPU force kernel in init().
start=s.index('void MD_CUDABackend::init()')
pre,tail=s[:start],s[start:]
anchor='\t_cuda_interaction->compute_forces(_cuda_lists, _d_poss, _d_orientations, _d_forces, _d_torques, _d_bonds, _d_cuda_box);'
body=r'''
	// Diagnostic only, initial arrays copied directly from the device.
	// This deliberately bypasses the host-side PairForce observable.
	if(const char *diag = std::getenv("OXDNA_DIAG_FORCE_DUMP")) {
		CUDA_SAFE_CALL(cudaMemcpy(_h_forces, _d_forces, _vec_size, cudaMemcpyDeviceToHost));
		CUDA_SAFE_CALL(cudaMemcpy(_h_torques, _d_torques, _vec_size, cudaMemcpyDeviceToHost));
		CUDA_SAFE_CALL(cudaMemcpy(_h_poss, _d_poss, _vec_size, cudaMemcpyDeviceToHost));
		std::FILE *fp = std::fopen(diag, "w");
		if(!fp) throw oxDNAException("CLN025 diagnostic: cannot write GPU force dump");
		for(int i=0; i<N(); ++i) {
			const unsigned int idx = GpuUtils::float_as_int(_h_poss[i].w) & 0x003FFFFF;
			std::fprintf(fp, "%u %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g %.17g\n", idx,
				double(_h_poss[i].x), double(_h_poss[i].y), double(_h_poss[i].z),
				double(_h_forces[i].x), double(_h_forces[i].y), double(_h_forces[i].z),
				double(_h_torques[i].x), double(_h_torques[i].y), double(_h_torques[i].z));
		}
		std::fclose(fp);
	}
'''
s=pre+replace_once(tail,anchor,anchor+body,'CUDA initial force hook')
# Norm of the actual device orientation, before it is normalized for host output.
anchor='\t_timer_thermostat->resume();\n\t_thermalize();\n\t_timer_thermostat->pause();'
body=r'''
	if(const char *diag = std::getenv("OXDNA_DIAG_QUAT_TRACE")) {
		if(current_step() % 5000 == 0) {
			CUDA_SAFE_CALL(cudaMemcpy(_h_orientations, _d_orientations, _orient_size, cudaMemcpyDeviceToHost));
			std::FILE *fp = std::fopen(diag, "a");
			if(!fp) throw oxDNAException("CLN025 diagnostic: cannot write quaternion trace");
			for(int i=0; i<N(); ++i) {
				const auto &q = _h_orientations[i];
				double q2 = double(q.x)*double(q.x)+double(q.y)*double(q.y)+double(q.z)*double(q.z)+double(q.w)*double(q.w);
				std::fprintf(fp, "%lld %d %.17g\n", (long long)current_step(), i, q2);
			}
			std::fclose(fp);
		}
	}
'''
s=replace_once(s,anchor,anchor+body,'CUDA quaternion trace hook')
gpu.write_text(s)
print('LOCAL_INSTRUMENTATION_OK',root)
