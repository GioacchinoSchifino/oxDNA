# Running the tests again

I ran the final tests on a Linux H100 compute node using the versions listed in `build/environment.txt`. Use an allocated GPU node with GCC, CUDA, CMake, Git and Python/NumPy available, and enough local scratch space. The pinned runner deletes any existing `--out` directory: use a new workspace. The script below creates one and does not edit any existing checkout.

## Uninstrumented runs

From the extracted bundle, run:

```bash
bash reproduce.sh extended /path/to/local/scratch
```

The script checks out the two oxDNA commits and the exact regression-suite commit. It applies the attached CLN025 patch to the scratch copy of the suite, builds CPU/mixed/double for each revision, runs the two targeted CLN025 `stat` checks on the original refactor, then both complete suites on the consolidated fixes. It keeps the full runner output and JSON, including failures. It uses 10 concurrent jobs by default and one concurrent GPU simulation; set `JOBS` to the number of allocated CPU cores if different.

For the original 300,000-step protocol on the same revisions, use a separate run:

```bash
bash reproduce.sh original /path/to/local/scratch
```

The `original` option does not apply the sampling patch. The wrapper returns a nonzero status if any runner does, even for the historical short-protocol failures. It also performs short targeted runs on the original refactor; the previously saved upstream short-protocol evidence came from the separate instrumented diagnostic, not from an uninstrumented upstream full suite.

The important build and runner commands (for one checkout) are:

```bash
cmake -S oxDNA -B build/cpu -DCUDA=OFF
cmake --build build/cpu --target oxDNA --parallel 10
cmake -S oxDNA -B build/mixed -DCUDA=ON -DCUDA_COMMON_ARCH=OFF
cmake --build build/mixed --target oxDNA --parallel 10
cmake -S oxDNA -B build/double -DCUDA=ON -DCUDA_DOUBLE=ON -DCUDA_COMMON_ARCH=OFF
cmake --build build/double --target oxDNA --parallel 10
python3 suite/run_tests.py --same-code \
  --old "$PWD/build/cpu/bin/oxDNA" --new "$PWD/build/mixed/bin/oxDNA" \
  --backend CUDA --cuda-precision mixed --jobs 10 --gpu-jobs 1 \
  --out "$PWD/results/core_mixed"
```

Use `--cuda-precision double` with the double binary and a distinct output directory. For a targeted comparison append `--only cln025/DNACT cln025/RNACT --stages stat`.

The observed final full result was 81 PASS, 25 SKIP and zero unexpected failures for each precision on `aa26e323`; the extended upstream targeted runs returned two PASS each. These are the measured H100 outcomes, not guaranteed outcomes on a different machine. The portable wrapper in this bundle follows the archived run commands and has been syntax-checked; the wrapper itself has not been executed on a GPU.

## Separate diagnostic runs

The exact diagnostic scripts from the earlier campaigns are in `methods/mechanism/` and `methods/john/`. These are research diagnostics, not changes proposed for upstream. They expect a checkout of the **unmodified** regression suite at `a1da3dfc...` and separate scratch source/build directories. Run them only with disposable source and result directories: they create run trees and remove completed temporary result trees after archiving evidence. They are included unchanged to show the methods actually used.

For the force/torque and thermostat comparison, use two source copies of oxDNA (`81dafaa3...` and `aa26e323...`). Run `methods/mechanism/instrument.py <source-copy>` once on each copy, then build CPU, mixed and double as above. Under a fresh work directory, arrange the executables at `build/{upstream,patched}/{cpu,cuda_mixed,cuda_double}/bin/oxDNA`. Then run:

```bash
python3 /path/to/bundle/methods/mechanism/diagnose.py "$WORK" "$REPORT" "$SUITE"
```

The script generates 12 perturbations from the equilibrated configuration (NumPy seed 236025) and compares the initialization force and body-frame torque arrays in addition to the three supplied configurations. It checks the quaternion norm every 5,000 steps and derives kinetic temperatures from the saved positions/orientations/momenta format. The recorded norms are for the device quaternion array used by the force kernels; this is not a direct measurement of every internal mixed-precision integration variable. It runs the original John tests and a separate Refresh comparison, retaining the original statistical thresholds.

For the 120-run John analysis, use a **fresh** source copy of `aa26e323...`, apply `methods/john/instrument.py <source-copy>` once and build to `build/{cpu,cuda_mixed,cuda_double}/bin/oxDNA` under a separate work directory. Then run:

```bash
python3 /path/to/bundle/methods/john/analyze.py "$WORK" "$REPORT" "$SUITE"
```

The CPU counter records actual refresh draws. The CUDA diagnostic infers a draw from changes to the three velocity or angular-momentum components across the thermostat call. Counters are saved at the first activation and every 100 activations thereafter, so the final partial interval may not be recorded. Refresh frequencies and moments refer to the recorded trials, not to every integration step. The code does not change the random-number generation or the acceptance thresholds. Instrumentation adds device copies and synchronization, so it is not intended for performance measurements.

The three conditions are D=1 / 1.2M steps, D=0.1 / 600k steps and D=0.01 / 300k steps; each has 16 CPU and 12 replicas per GPU precision. The diagnostic uses disjoint seed sets, and compares the two halves of the CPU cohort as well as CPU versus each GPU cohort. The original regression criterion and the replica-level bootstrap/permutation summaries are descriptive checks, not a formal equivalence test. A translational count z of 3.105 at D=0.1 in mixed is retained in the results; no multiple-testing correction is applied to these diagnostic z-scores. The short- and long-protocol comparisons that support the sampling patch use the uninstrumented builds above.
