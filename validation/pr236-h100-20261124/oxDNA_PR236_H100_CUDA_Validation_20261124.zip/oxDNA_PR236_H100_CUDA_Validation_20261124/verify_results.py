#!/usr/bin/env python3
"""Check the saved ANM reports. This does not run oxDNA or read trajectories."""
import argparse
from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
from statistics import mean, stdev

TARGET = {('cln025/DNACT', 'stat'), ('cln025/RNACT', 'stat')}
SHORT = {'PASS': 79, 'SKIP': 25, 'FAIL': 2}
LONG = {'PASS': 81, 'SKIP': 25}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-12)


def read_json(path):
    def invalid(x):
        raise ValueError(f'{path}: nonfinite JSON number {x}')
    return json.loads(path.read_text(), parse_constant=invalid)


def check_hashes(root):
    files = {}
    for line in (root / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts, f'Invalid path: {name}')
        require(name not in files, f'Duplicate checksum: {name}')
        require((root / name).is_file(), f'Missing {name}')
        require(sha256((root / name).read_bytes()).hexdigest() == digest, f'Checksum mismatch: {name}')
        files[name] = digest
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(actual == set(files) | {'SHA256SUMS'}, 'Unexpected or missing files')
    manifest = read_json(root / 'source_manifest.json')
    entries = manifest['copied_or_derived_files']
    require(len({r['file'] for r in entries}) == len(entries), 'Duplicate source-manifest entries')
    for r in entries:
        require(files.get(r['file']) == r['sha256'], f'Source-manifest mismatch: {r["file"]}')
    return len(files), len(entries)


def checks(path):
    records = read_json(path)
    result = {}
    for row in records:
        for name, val in row['checks'].items():
            k = (row['case'], name)
            require(k not in result, f'Duplicate check {k} in {path}')
            result[k] = val
    return result


def statuses(x):
    return {k: v['status'] for k, v in x.items()}


def mixed_original(path):
    result = {}
    for line in path.read_text().splitlines():
        if not line.startswith('| '):
            continue
        cells = line.split('|', 4)
        if len(cells) != 5:
            continue
        case, check, status = (s.strip() for s in cells[1:4])
        if status in {'PASS', 'FAIL', 'SKIP', 'ERROR', 'XFAIL', 'XPASS'}:
            k = (case, check)
            require(k not in result, f'Duplicate text-summary check {k}')
            result[k] = status
    return result


def cln025_stat(check):
    # Pinned runner defaults for this fixture, not a general statistical test.
    d = check['data']
    a, b = d['old'], d['new']
    r, s, er, es = a['rmsf'], b['rmsf'], a['rmsf_se'], b['rmsf_se']
    require(len(r) == len(s) == len(er) == len(es) == 10, 'CLN025 shape')
    require(all(x >= 0 for x in r + s + er + es), 'Negative RMSF or uncertainty')
    ma, mb = mean(r), mean(s)
    z = [(y-x)/max(math.hypot(u,v),1e-6) for x,y,u,v in zip(r,s,er,es)]
    z2 = mean(x*x for x in z)
    nout = sum(abs(x)>4 for x in z)
    de = b['E_mean']-a['E_mean']
    se = math.hypot(a['E_se'], b['E_se'])
    ez = de/max(se,1e-12)
    fail = (abs(de)>4*se+2e-5 or nout>1 or z2>4 or
            abs(mb-ma)>4*math.hypot(mean(er),mean(es))+.02*ma)
    require(close(z2,d['rmsf_mean_z2']), 'RMSF mean z² mismatch')
    require(close(nout/10,d['rmsf_frac_outliers']), 'RMSF outlier fraction mismatch')
    require(close(ma,d['rmsf_mean'][0]) and close(mb,d['rmsf_mean'][1]), 'RMSF mean mismatch')
    require(close(ez,d['E_z']), 'Energy z mismatch')
    require(check['status']==('FAIL' if fail else 'PASS'), 'CLN025 stat verdict mismatch')
    return {'cpu_rmsf':ma,'gpu_rmsf':mb,'mean_z2':z2,'outliers':nout,'energy_z':ez,'status':check['status']}


def verify(root):
    file_count, source_count = check_hashes(root)
    data = root/'data'
    original = {'mixed':mixed_original(data/'full_mixed_original_summary.md'),
                'double':statuses(checks(data/'full_double_original/results.json'))}
    full_report, cln_report = {}, {}
    for prec in ('mixed','double'):
        original_status = original[prec]
        full = checks(data/f'core_{prec}_full/results.json')
        final_status = statuses(full)
        require(Counter(original_status.values()) == SHORT, f'{prec}: original counts')
        require(Counter(final_status.values()) == LONG, f'{prec}: updated counts')
        require(set(original_status)==set(final_status) and len(full)==106, f'{prec}: changed coverage')
        require(len({k[0] for k in full})==27, f'{prec}: case count')
        require({k for k in full if original_status[k]!=final_status[k]}==TARGET, f'{prec}: changed non-target statuses')
        require(all(original_status[k]=='FAIL' and final_status[k]=='PASS' for k in TARGET), f'{prec}: target transition')
        require(all(k[1]=='det' for k,v in final_status.items() if v=='SKIP'), f'{prec}: unexpected skip')
        stages=Counter(k[1]+'_'+v for k,v in final_status.items())
        require(stages=={'energy0_PASS':27,'nve_PASS':27,'stat_PASS':25,'stat_dh_off_PASS':2,'det_SKIP':25},f'{prec}: stage coverage')
        target=checks(data/f'upstream_{prec}_target/results.json')
        retest=checks(data/f'cln025_{prec}_long/results.json')
        require(set(target)==set(retest)==TARGET,f'{prec}: targeted coverage')
        require(all(target[k]==retest[k]==full[k] for k in TARGET),f'{prec}: targeted and full results differ')
        std=checks(data/f'cln025_{prec}_std.json')
        shifted=checks(data/f'cln025_{prec}_shift.json')
        require(std[('cln025/AC','stat')]==full[('cln025/AC','stat')],f'{prec}: AC control mismatch')
        for k in TARGET:
            for label, result, state, frames in [('original',std,'FAIL',4800),('shifted',shifted,'FAIL',4800),('extended',target,'PASS',19200)]:
                x=result[k];require(x['status']==state,f'{prec}: {label} {k} state')
                for side in ('old','new'):
                    require(x['data'][side]['replicas']==8 and x['data'][side]['n_frames']==frames,f'{prec}: {label} {k} frame/replica count')
                cln_report[f'{prec}/{label}/{k[0]}']=cln025_stat(x)
        full_report[prec]={'original':dict(Counter(original_status.values())), 'extended':dict(Counter(final_status.values())), 'same_check_keys':True,'changed_statuses':sorted('/'.join(k) for k in TARGET),'stage_counts':dict(stages)}
    require(set(original['mixed'])==set(original['double']),'Precision coverage differs')
    # Diagnostic comparisons of initial force/torque arrays: saved summaries only.
    diag=root/'diagnostics'
    probes=read_json(diag/'direct_force_comparison.json')
    require(not probes['errors'] and len(probes['records'])==60,'Incomplete direct force probes')
    force_report={}
    for src in ('upstream','patched'):
        for bk in ('cuda_mixed','cuda_double'):
            rows=[x for x in probes['records'] if x['source']==src and x['backend']==bk]
            require(len(rows)==len({x['snapshot'] for x in rows})==15,'Force probe coverage')
            for x in rows:
                for k in ('position','force','torque'):
                    d=x[k]; a,b=d['ref'],d['test']
                    require(close(abs(a-b)/(1+abs(a)+abs(b)),d['max_scaled']),'Scaled force diagnostic mismatch')
                    require(d['max_abs']+1e-12>=abs(a-b)>=0,'Force error summary inconsistent')
            force_report[src+'_'+bk]={k:max(x[k]['max_scaled'] for x in rows) for k in ('force','torque')}
    # Thermostat statistics: recalculate pooled counts/moments and replica averages.
    john_report={}; seeds=[]
    for s in read_json(diag/'john_summary.json'):
        cohort=read_json(diag/(s['condition']+'_replicas.json'))
        rows=cohort['rows'];require(not cohort['errors'] and len(rows)==40,'John cohort incomplete')
        seeds.extend(x['seed'] for x in rows)
        groups={}
        for bk,nrep in [('cpu',16),('cuda_mixed',12),('cuda_double',12)]:
            b=sorted([x for x in rows if x['backend']==bk],key=lambda x:x['seed']);groups[bk]=b
            require(len(b)==nrep,'John backend replica count')
            require(all(x['nframes']==s['steps']//500 for x in b),'John saved frame count')
            h=s['backends'][bk];trials=sum(x['counter']['trials'] for x in b)
            require(trials==h['trials'] and all(x['counter']['trials']==10*x['counter']['activations'] for x in b),'John trial count')
            require(all(0<=s['steps']//51-x['counter']['activations']<=100 for x in b),'John saved counter coverage')
            counts=[sum(x['counter']['counts'][i] for x in b) for i in range(2)]
            require(counts==h['draws'],'John draw count')
            p=[2*.1*51*.002/(.1*51*.002+i*s['diff_coeff']) for i in (2,6)]
            for i in range(2):
                require(close(p[i],h['expected_probability'][i]) and close(counts[i]/trials,h['observed_probability'][i]),'John refresh probability')
                z=(counts[i]-trials*p[i])/math.sqrt(trials*p[i]*(1-p[i]))
                require(close(z,h['count_z_binomial'][i]),'John count z')
                for k in range(3):
                    m=sum(x['counter']['sum'][i][k] for x in b)/counts[i]
                    v=sum(x['counter']['sumsq'][i][k] for x in b)/counts[i]-m*m
                    require(close(m,h['draw_mean_xyz'][i][k]) and close(v,h['draw_variance_xyz'][i][k]),'John draw moments')
            for name in ('Ttrans','Trot'):
                a=[x[name] for x in b]; m,se=h[name+'_mean_se']
                require(close(mean(a),m) and close(stdev(a)/math.sqrt(nrep),se),'John kinetic temperature')
        john_report[s['condition']]={}
        for name,a,b in [('cpu_cpu',groups['cpu'][:8],groups['cpu'][8:]),('cpu_mixed',groups['cpu'],groups['cuda_mixed']),('cpu_double',groups['cpu'],groups['cuda_double'])]:
            c=s['comparisons'][name];d=c['original_stat'];q=cln025_stat(d)
            require(q['status']=='PASS','John statistical comparison failed')
            for side,rs in [('old',a),('new',b)]:
                rr=d['data'][side];require(rr['replicas']==len(rs),'John statistical replica count')
                for i in range(10):
                    v=[x['rmsf'][i] for x in rs]
                    require(close(mean(v),rr['rmsf'][i]) and close(stdev(v)/math.sqrt(len(v)),rr['rmsf_se'][i]),'John per-replica RMSF aggregate')
            # Check the reported scalar differences; bootstrap draws themselves are not stored.
            for key,field in [('full','rmsf'),('first300k','rmsf_first300k'),('last_half','rmsf_last_half')]:
                x=mean(mean(r[field]) for r in a);y=mean(mean(r[field]) for r in b);m=c[key]
                require(close(x,m['old_mean']) and close(y,m['new_mean']) and close(y-x,m['delta']),'John replica-level difference')
            john_report[s['condition']][name]=q
    require(len(seeds)==len(set(seeds))==120 and len(john_report)==3,'John seed/condition coverage')
    return {'audit_pass':True,'files_verified':file_count,'source_records_verified':source_count,'full_regression':full_report,'cln025':cln_report,'direct_force_summary':force_report,'john':john_report,'limitations':'Checks saved reports and replica aggregates; not raw trajectory, device-array or binary verification.'}


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent)
    args=ap.parse_args()
    print(json.dumps(verify(args.directory.resolve()),indent=2,allow_nan=False))
