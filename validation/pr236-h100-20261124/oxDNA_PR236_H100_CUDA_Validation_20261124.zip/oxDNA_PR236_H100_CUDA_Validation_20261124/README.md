# ANM tests on H100

Gioacchino Schifino — 24 November 2026

This is the follow-up to the CUDA validation of my ANM fixes in PR #2. `ANM_VALIDATION_NOTE.md` describes the two CLN025 failures, the checks I ran to investigate them, and the results after increasing the sampling length.

`CLN025_stat_sampling.patch` is the regression-suite change used in the final runs. `data/` contains the regression reports; `diagnostics/` and `methods/` contain the additional measurements and the diagnostic code. Build information and source provenance are in `build/` and `source_manifest.json`.

To check the saved results without running oxDNA:

```bash
python3 verify_results.py
```

To rerun the regressions, see `REPRODUCE.md`. The diagnostic instrumentation is separate from the proposed patch and was not used for the final full regression runs. No additional CI workflow is proposed.
