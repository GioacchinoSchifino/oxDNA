# ANM/oxNA regression results (CUDA)

- mode: same code (reference = CPU build of the code under test)
- old/reference: [local executable path omitted]
- new/test: [local executable path omitted]
- wall time: 1064 s

| case | check | status | details |
|---|---|---|---|
| cage/DNANM | energy0 | PASS | default: ref -0.298704 test -0.298705 diff -1.00e-06; new: GPU -0.298709 vs host -0.298707 (-2.0e-06); non-protein terms (E - E_numpy_protein): ref -0.380868 test -0.380869 |
| cage/DNANM | det | SKIP | not comparable across backends |
| cage/DNANM | stat | PASS | <E> old -0.50392+-0.00170 new -0.50292+-0.00111 (z +0.5); RMSF mean old 0.605 new 0.604 A, 5/605 residues /z/>4, <z^2> 1.45; RMSF(NA) mean old 3.751 new 3.831 A, 0/393 residues /z/>4, <z^2> 1.34 (not tested) |
| cage/DNANM | nve | PASS | conserved E drift over 20 time units: ref -4.03e-05 test +7.25e-05; fluct ref 1.2e-05 test 1.5e-05 (per particle) |
| cage/DNACT | energy0 | PASS | default: ref -0.243505 test -0.243506 diff -1.00e-06; new: GPU -0.243511 vs host -0.243508 (-3.0e-06); non-protein terms (E - E_numpy_protein): ref -0.380868 test -0.380869 |
| cage/DNACT | det | SKIP | not comparable across backends |
| cage/DNACT | stat | PASS | <E> old -0.43663+-0.00180 new -0.43544+-0.00179 (z +0.5); RMSF mean old 0.580 new 0.566 A, 6/605 residues /z/>4, <z^2> 1.75; RMSF(NA) mean old 3.765 new 3.780 A, 3/393 residues /z/>4, <z^2> 1.87 (not tested) |
| cage/DNACT | nve | PASS | conserved E drift over 20 time units: ref -1.42e-05 test +1.11e-05; fluct ref 1.7e-05 test 1.8e-05 (per particle) |
| cln025/AC | energy0 | PASS | default: ref 0.246245 test 0.246245 diff +0.00e+00; new: GPU 0.246243 vs host 0.246243 (+0.0e+00); old-numpy +3.14e-07; new-numpy +3.14e-07 |
| cln025/AC | det | SKIP | not comparable across backends |
| cln025/AC | stat | PASS | <E> old 0.12142+-0.00155 new 0.12114+-0.00333 (z -0.1); RMSF mean old 0.654 new 0.659 A, 0/10 residues /z/>4, <z^2> 0.07; vs ANM prediction: r=0.64, sim/ANM=1.41 |
| cln025/AC | nve | PASS | conserved E drift over 20 time units: ref +1.51e-06 test +2.84e-06; fluct ref 1.6e-06 test 2.5e-06 (per particle) |
| cln025/DNACT | energy0 | PASS | default: ref 1.082646 test 1.082646 diff +0.00e+00; new: GPU 1.082642 vs host 1.082642 (+0.0e+00); old-numpy -3.70e-08; new-numpy -3.70e-08 |
| cln025/DNACT | det | SKIP | not comparable across backends |
| cln025/DNACT | stat | FAIL | <E> old 0.26682+-0.00276 new 0.25238+-0.00625 (z -2.1); RMSF mean old 0.411 new 0.393 A, 0/10 residues /z/>4, <z^2> 5.73; RMSF mismatch; vs ANM prediction: r=0.94, sim/ANM=0.84 |
| cln025/DNACT | nve | PASS | conserved E drift over 20 time units: ref +1.87e-06 test +2.31e-06; fluct ref 2.7e-06 test 4.1e-06 (per particle) |
| cln025/RNACT | energy0 | PASS | default: ref 1.082646 test 1.082646 diff +0.00e+00; new: GPU 1.082642 vs host 1.082642 (+0.0e+00); old-numpy -3.70e-08; new-numpy -3.70e-08 |
| cln025/RNACT | det | SKIP | not comparable across backends |
| cln025/RNACT | stat | FAIL | <E> old 0.26682+-0.00276 new 0.25238+-0.00625 (z -2.1); RMSF mean old 0.411 new 0.393 A, 0/10 residues /z/>4, <z^2> 5.73; RMSF mismatch; vs ANM prediction: r=0.94, sim/ANM=0.84 |
| cln025/RNACT | nve | PASS | conserved E drift over 20 time units: ref +1.87e-06 test +2.31e-06; fluct ref 2.7e-06 test 4.1e-06 (per particle) |
| kdpg/ANMT | energy0 | PASS | default: ref 1.209537 test 1.209536 diff -1.00e-06; new: GPU 1.209536 vs host 1.209536 (+0.0e+00); old-numpy -2.69e-08; new-numpy -1.03e-06 |
| kdpg/ANMT | det | SKIP | not comparable across backends |
| kdpg/ANMT | stat | PASS | <E> old 0.31031+-0.00273 new 0.31386+-0.00168 (z +1.1); RMSF mean old 0.537 new 0.547 A, 6/605 residues /z/>4, <z^2> 1.68 |
| kdpg/ANMT | nve | PASS | conserved E drift over 20 time units: ref -6.97e-05 test +2.63e-05; fluct ref 2.6e-05 test 1.9e-05 (per particle) |
| kdpg/DNANM | energy0 | PASS | default: ref 0.082090 test 0.082090 diff +0.00e+00; new: GPU 0.082090 vs host 0.082090 (+0.0e+00); old-numpy -2.75e-07; new-numpy -2.75e-07 |
| kdpg/DNANM | det | SKIP | not comparable across backends |
| kdpg/DNANM | stat | PASS | <E> old 0.14784+-0.00148 new 0.14939+-0.00122 (z +0.8); RMSF mean old 0.554 new 0.570 A, 5/605 residues /z/>4, <z^2> 1.68 |
| kdpg/DNANM | nve | PASS | conserved E drift over 20 time units: ref +2.16e-04 test +1.30e-04; fluct ref 2.4e-05 test 2.1e-05 (per particle) |
| na_dna_duplex/NA | energy0 | PASS | default: ref -1.161387 test -1.161386 diff +1.00e-06; new: GPU -1.161390 vs host -1.161386 (-4.0e-06) |
| na_dna_duplex/NA | det | SKIP | not comparable across backends |
| na_dna_duplex/NA | stat | PASS | <E> old -1.29144+-0.02762 new -1.29244+-0.01341 (z -0.0); RMSF mean old 1.731 new 1.664 A, 0/22 residues /z/>4, <z^2> 0.52 |
| na_dna_duplex/NA | nve | PASS | conserved E drift over 20 time units: ref +6.48e-05 test +8.85e-05; fluct ref 7.5e-05 test 6.3e-05 (per particle) |
| na_hybrid_overhang/NA | energy0 | PASS | default: ref -1.295012 test -1.295012 diff +0.00e+00; new: GPU -1.295005 vs host -1.295013 (+8.0e-06) |
| na_hybrid_overhang/NA | det | SKIP | not comparable across backends |
| na_hybrid_overhang/NA | stat | PASS | <E> old -1.37552+-0.01006 new -1.37483+-0.00846 (z +0.1); RMSF mean old 2.292 new 2.134 A, 0/30 residues /z/>4, <z^2> 0.37 |
| na_hybrid_overhang/NA | nve | PASS | conserved E drift over 20 time units: ref +6.34e-06 test +1.59e-04; fluct ref 1.0e-05 test 5.2e-05 (per particle) |
| na_mixed/NA | energy0 | PASS | default: ref -1.186885 test -1.186886 diff -1.00e-06; new: GPU -1.186886 vs host -1.186886 (+0.0e+00) |
| na_mixed/NA | det | SKIP | not comparable across backends |
| na_mixed/NA | stat | PASS | <E> old -1.24332+-0.00586 new -1.23081+-0.00546 (z +1.6); RMSF mean old 1.614 new 1.645 A, 0/22 residues /z/>4, <z^2> 0.61 |
| na_mixed/NA | nve | PASS | conserved E drift over 20 time units: ref -2.30e-05 test -2.65e-05; fluct ref 6.0e-06 test 6.3e-06 (per particle) |
| na_rna_duplex/NA | energy0 | PASS | default: ref -1.358674 test -1.358675 diff -1.00e-06; new: GPU -1.358675 vs host -1.358676 (+1.0e-06) |
| na_rna_duplex/NA | det | SKIP | not comparable across backends |
| na_rna_duplex/NA | stat | PASS | <E> old -1.47196+-0.00866 new -1.49128+-0.00690 (z -1.7); RMSF mean old 1.525 new 1.461 A, 0/24 residues /z/>4, <z^2> 0.82 |
| na_rna_duplex/NA | nve | PASS | conserved E drift over 20 time units: ref -1.79e-04 test +2.49e-04; fluct ref 4.4e-05 test 5.0e-05 (per particle) |
| ubiquitin/DNACT | energy0 | PASS | default: ref 0.169886 test 0.169886 diff +0.00e+00; new: GPU 0.169886 vs host 0.169886 (+0.0e+00); old-numpy -2.13e-07; new-numpy -2.13e-07 |
| ubiquitin/DNACT | det | SKIP | not comparable across backends |
| ubiquitin/DNACT | stat | PASS | <E> old 0.28940+-0.00402 new 0.28085+-0.00437 (z -1.4); RMSF mean old 0.556 new 0.554 A, 1/76 residues /z/>4, <z^2> 1.21; vs ANM prediction: r=0.99, sim/ANM=0.85 |
| ubiquitin/DNACT | nve | PASS | conserved E drift over 20 time units: ref -9.55e-05 test -1.66e-05; fluct ref 3.8e-05 test 8.9e-05 (per particle) |
| ubiquitin/DNANM | energy0 | PASS | default: ref 0.060555 test 0.060555 diff +0.00e+00; new: GPU 0.060555 vs host 0.060555 (+0.0e+00); old-numpy +7.50e-08; new-numpy +7.50e-08 |
| ubiquitin/DNANM | det | SKIP | not comparable across backends |
| ubiquitin/DNANM | stat | PASS | <E> old 0.14456+-0.00267 new 0.14262+-0.00198 (z -0.6); RMSF mean old 0.642 new 0.634 A, 1/76 residues /z/>4, <z^2> 1.60; vs ANM prediction: r=0.97, sim/ANM=0.97 |
| ubiquitin/DNANM | nve | PASS | conserved E drift over 20 time units: ref -1.91e-04 test -2.08e-04; fluct ref 6.2e-05 test 5.3e-05 (per particle) |
| ubiquitin/RNANM | energy0 | PASS | default: ref 0.060555 test 0.060555 diff +0.00e+00; new: GPU 0.060555 vs host 0.060555 (+0.0e+00); old-numpy +7.50e-08; new-numpy +7.50e-08 |
| ubiquitin/RNANM | det | SKIP | not comparable across backends |
| ubiquitin/RNANM | stat | PASS | <E> old 0.14456+-0.00267 new 0.14262+-0.00198 (z -0.6); RMSF mean old 0.642 new 0.634 A, 1/76 residues /z/>4, <z^2> 1.60; vs ANM prediction: r=0.97, sim/ANM=0.97 |
| ubiquitin/RNANM | nve | PASS | conserved E drift over 20 time units: ref -1.91e-04 test -2.08e-04; fluct ref 6.2e-05 test 5.3e-05 (per particle) |
| ubiquitin/RNACT | energy0 | PASS | default: ref 0.169886 test 0.169886 diff +0.00e+00; new: GPU 0.169886 vs host 0.169886 (+0.0e+00); old-numpy -2.13e-07; new-numpy -2.13e-07 |
| ubiquitin/RNACT | det | SKIP | not comparable across backends |
| ubiquitin/RNACT | stat | PASS | <E> old 0.28940+-0.00402 new 0.28085+-0.00437 (z -1.4); RMSF mean old 0.556 new 0.554 A, 1/76 residues /z/>4, <z^2> 1.21; vs ANM prediction: r=0.99, sim/ANM=0.85 |
| ubiquitin/RNACT | nve | PASS | conserved E drift over 20 time units: ref -9.55e-05 test -1.66e-05; fluct ref 3.8e-05 test 8.9e-05 (per particle) |
| ubq_dna/DNANM | energy0 | PASS | default: ref -0.241033 test -0.241034 diff -1.00e-06; new: GPU -0.241041 vs host -0.241034 (-7.0e-06); non-protein terms (E - E_numpy_protein): ref -0.287055 test -0.287056 |
| ubq_dna/DNANM | det | SKIP | not comparable across backends |
| ubq_dna/DNANM | stat | PASS | <E> old -0.23166+-0.00222 new -0.23748+-0.00262 (z -1.7); RMSF mean old 0.632 new 0.627 A, 2/76 residues /z/>4, <z^2> 1.73; RMSF(NA) mean old 1.329 new 1.248 A, 0/24 residues /z/>4, <z^2> 1.65 (not tested) |
| ubq_dna/DNANM | nve | PASS | conserved E drift over 20 time units: ref -1.30e-04 test +3.44e-04; fluct ref 4.7e-05 test 6.4e-05 (per particle) |
| ubq_dna/DNACT | energy0 | PASS | default: ref -0.157942 test -0.157942 diff +0.00e+00; new: GPU -0.157949 vs host -0.157942 (-7.0e-06); non-protein terms (E - E_numpy_protein): ref -0.287056 test -0.287056 |
| ubq_dna/DNACT | det | SKIP | not comparable across backends |
| ubq_dna/DNACT | stat | PASS | <E> old -0.12646+-0.00192 new -0.13274+-0.00359 (z -1.5); RMSF mean old 0.556 new 0.547 A, 0/76 residues /z/>4, <z^2> 1.29; RMSF(NA) mean old 1.345 new 1.232 A, 0/24 residues /z/>4, <z^2> 2.41 (not tested) |
| ubq_dna/DNACT | nve | PASS | conserved E drift over 20 time units: ref -4.43e-05 test +2.88e-05; fluct ref 3.7e-05 test 2.7e-05 (per particle) |
| ubq_dna_nt/NANM | energy0 | PASS | default: ref -0.241033 test -0.241034 diff -1.00e-06; new: GPU -0.241041 vs host -0.241034 (-7.0e-06); non-protein terms (E - E_numpy_protein): ref -0.287055 test -0.287056 |
| ubq_dna_nt/NANM | det | SKIP | not comparable across backends |
| ubq_dna_nt/NANM | stat | PASS | <E> old -0.23154+-0.00445 new -0.23913+-0.00228 (z -1.5); RMSF mean old 0.627 new 0.618 A, 0/76 residues /z/>4, <z^2> 1.35; RMSF(NA) mean old 1.389 new 1.326 A, 0/24 residues /z/>4, <z^2> 0.22 (not tested) |
| ubq_dna_nt/NANM | nve | PASS | conserved E drift over 20 time units: ref -5.51e-05 test -1.31e-04; fluct ref 3.6e-05 test 4.0e-05 (per particle) |
| ubq_dna_nt/NACT | energy0 | PASS | default: ref -0.157942 test -0.157942 diff +0.00e+00; new: GPU -0.157949 vs host -0.157942 (-7.0e-06); non-protein terms (E - E_numpy_protein): ref -0.287056 test -0.287056 |
| ubq_dna_nt/NACT | det | SKIP | not comparable across backends |
| ubq_dna_nt/NACT | stat | PASS | <E> old -0.13084+-0.00494 new -0.13115+-0.00430 (z -0.0); RMSF mean old 0.563 new 0.551 A, 0/76 residues /z/>4, <z^2> 1.34; RMSF(NA) mean old 1.269 new 1.256 A, 0/24 residues /z/>4, <z^2> 0.12 (not tested) |
| ubq_dna_nt/NACT | nve | PASS | conserved E drift over 20 time units: ref +9.22e-05 test +2.51e-04; fluct ref 8.5e-05 test 8.7e-05 (per particle) |
| ubq_dna_wall/DNANM | energy0 | PASS | default: ref 0.836236 test 0.836236 diff +0.00e+00; new: GPU 0.836237 vs host 0.836236 (+1.0e-06); non-protein terms (E - E_numpy_protein): ref -0.338778 test -0.338778 |
| ubq_dna_wall/DNANM | nve | PASS | conserved E drift over 5 time units: ref -3.54e-04 test -6.12e-04; fluct ref 3.3e-04 test 2.0e-04 (per particle) |
| ubq_dna_wall/DNACT | energy0 | PASS | default: ref 1.149227 test 1.149227 diff +0.00e+00; new: GPU 1.149227 vs host 1.149226 (+1.0e-06); non-protein terms (E - E_numpy_protein): ref -0.338777 test -0.338777 |
| ubq_dna_wall/DNACT | nve | PASS | conserved E drift over 5 time units: ref +7.56e-04 test -6.84e-04; fluct ref 3.3e-04 test 3.6e-04 (per particle) |
| ubq_hybrid/NANM | energy0 | PASS | default: ref -0.256789 test -0.256789 diff +0.00e+00; new: GPU -0.256790 vs host -0.256790 (+0.0e+00); non-protein terms (E - E_numpy_protein): ref -0.300206 test -0.300206 |
| ubq_hybrid/NANM | det | SKIP | not comparable across backends |
| ubq_hybrid/NANM | stat | PASS | <E> old -0.29302+-0.00216 new -0.27894+-0.00337 (z +3.5); RMSF mean old 0.622 new 0.622 A, 0/76 residues /z/>4, <z^2> 1.05; RMSF(NA) mean old 2.054 new 2.746 A, 0/30 residues /z/>4, <z^2> 3.05 (not tested) |
| ubq_hybrid/NANM | nve | PASS | conserved E drift over 20 time units: ref +4.14e-04 test +3.17e-04; fluct ref 3.2e-05 test 3.3e-05 (per particle) |
| ubq_hybrid/NACT | energy0 | PASS | default: ref -0.178401 test -0.178401 diff +0.00e+00; new: GPU -0.178401 vs host -0.178401 (+0.0e+00); non-protein terms (E - E_numpy_protein): ref -0.300206 test -0.300206 |
| ubq_hybrid/NACT | det | SKIP | not comparable across backends |
| ubq_hybrid/NACT | stat | PASS | <E> old -0.18975+-0.00381 new -0.18426+-0.00469 (z +0.9); RMSF mean old 0.560 new 0.555 A, 0/76 residues /z/>4, <z^2> 0.93; RMSF(NA) mean old 2.295 new 2.502 A, 0/30 residues /z/>4, <z^2> 1.20 (not tested) |
| ubq_hybrid/NACT | nve | PASS | conserved E drift over 20 time units: ref -4.00e-05 test +5.17e-05; fluct ref 3.2e-05 test 3.2e-05 (per particle) |
| ubq_rna/RNANM | energy0 | PASS | default: ref -0.274667 test -0.274667 diff +0.00e+00; _dh_off: ref -0.275158 test -0.275158 diff +0.00e+00; new: GPU -0.274664 vs host -0.274664 (+0.0e+00); new_dh_off: GPU -0.275155 vs host -0.275155 (+0.0e+00); non-protein terms (E - E_numpy_protein): ref -0.320689 test -0.320689; DH term ref 0.000491 test 0.000491 ratio 1.000 |
| ubq_rna/RNANM | det | SKIP | not comparable across backends |
| ubq_rna/RNANM | stat_dh_off | PASS | <E> old -0.25270+-0.00303 new -0.25374+-0.00074 (z -0.3); RMSF mean old 0.626 new 0.627 A, 0/76 residues /z/>4, <z^2> 0.83; RMSF(NA) mean old 1.593 new 1.531 A, 0/24 residues /z/>4, <z^2> 0.89 (not tested) |
| ubq_rna/RNANM | stat | PASS | <E> old -0.25341+-0.00155 new -0.25329+-0.00285 (z +0.0); RMSF mean old 0.625 new 0.621 A, 0/76 residues /z/>4, <z^2> 1.13; RMSF(NA) mean old 1.581 new 1.479 A, 0/24 residues /z/>4, <z^2> 2.28 (not tested) |
| ubq_rna/RNANM | nve | PASS | conserved E drift over 20 time units: ref -1.48e-04 test +1.54e-05; fluct ref 2.1e-05 test 3.3e-05 (per particle) |
| ubq_rna/RNACT | energy0 | PASS | default: ref -0.191575 test -0.191575 diff +0.00e+00; _dh_off: ref -0.192066 test -0.192066 diff +0.00e+00; new: GPU -0.191572 vs host -0.191572 (+0.0e+00); new_dh_off: GPU -0.192063 vs host -0.192063 (+0.0e+00); non-protein terms (E - E_numpy_protein): ref -0.320689 test -0.320689; DH term ref 0.000491 test 0.000491 ratio 1.000 |
| ubq_rna/RNACT | det | SKIP | not comparable across backends |
| ubq_rna/RNACT | stat_dh_off | PASS | <E> old -0.14248+-0.00193 new -0.14761+-0.00482 (z -1.0); RMSF mean old 0.554 new 0.552 A, 0/76 residues /z/>4, <z^2> 0.96; RMSF(NA) mean old 1.647 new 1.518 A, 0/24 residues /z/>4, <z^2> 2.35 (not tested) |
| ubq_rna/RNACT | stat | PASS | <E> old -0.14885+-0.00378 new -0.14975+-0.00338 (z -0.2); RMSF mean old 0.549 new 0.544 A, 0/76 residues /z/>4, <z^2> 1.10; RMSF(NA) mean old 1.483 new 1.497 A, 0/24 residues /z/>4, <z^2> 0.45 (not tested) |
| ubq_rna/RNACT | nve | PASS | conserved E drift over 20 time units: ref -1.20e-04 test -1.60e-04; fluct ref 3.4e-05 test 3.7e-05 (per particle) |
| ubq_rna_nt/NANM | energy0 | PASS | default: ref -0.274667 test -0.274667 diff +0.00e+00; new: GPU -0.274665 vs host -0.274665 (+0.0e+00); non-protein terms (E - E_numpy_protein): ref -0.320689 test -0.320689 |
| ubq_rna_nt/NANM | det | SKIP | not comparable across backends |
| ubq_rna_nt/NANM | stat | PASS | <E> old -0.25189+-0.00327 new -0.25319+-0.00203 (z -0.3); RMSF mean old 0.616 new 0.616 A, 0/76 residues /z/>4, <z^2> 0.81; RMSF(NA) mean old 1.651 new 1.629 A, 0/24 residues /z/>4, <z^2> 0.28 (not tested) |
| ubq_rna_nt/NANM | nve | PASS | conserved E drift over 20 time units: ref -1.89e-04 test -1.06e-04; fluct ref 6.2e-05 test 2.0e-05 (per particle) |
| ubq_rna_nt/NACT | energy0 | PASS | default: ref -0.191575 test -0.191575 diff +0.00e+00; new: GPU -0.191572 vs host -0.191573 (+1.0e-06); non-protein terms (E - E_numpy_protein): ref -0.320689 test -0.320689 |
| ubq_rna_nt/NACT | det | SKIP | not comparable across backends |
| ubq_rna_nt/NACT | stat | PASS | <E> old -0.14872+-0.00244 new -0.15068+-0.00498 (z -0.4); RMSF mean old 0.549 new 0.546 A, 0/76 residues /z/>4, <z^2> 0.99; RMSF(NA) mean old 1.558 new 1.526 A, 0/24 residues /z/>4, <z^2> 0.80 (not tested) |
| ubq_rna_nt/NACT | nve | PASS | conserved E drift over 20 time units: ref -3.31e-04 test -2.59e-04; fluct ref 4.2e-05 test 3.8e-05 (per particle) |

totals: FAIL 2, PASS 79, SKIP 25

**2 unexpected failure(s)**

